#### Load packages ####

library(tidyverse)

#### Load data #### 

data.bib <- readRDS("wos+cwts_all_records_data.Rds")  # Load dataset containing Web of Science and CWTS bibliometrics for all records identified by our initial literature search.
data.all <- readRDS("dataset_A_updated_data.rds")  # Load dataset randomly sampled from data.bib for which sample size has also been coded 
data.irr <- readRDS("dataset_B_inter_rater_reliability.Rds")  # Load dataset randomly sampled from data.all, used for checking sample size coding inter-rater reliability
codebook.data.all <- read.table("dataset_A_data_codebook.tsv", header = T, row.names = 1, sep = "\t")



#### Clean data ####

# transpose codebook to facilitate easy look-up of variable definitions

codebook.data.all <- as.data.frame(t(codebook.data.all))

# Set numeric variables to numeric in data.bib and data.all

data.bib$TC <- as.numeric(data.bib$TC)
data.bib$TC_2020 <- as.numeric(data.bib$TC_2020)
data.bib$PY <- as.numeric(data.bib$PY)

data.all$TC <- as.numeric(data.all$TC)
data.all$TC_2020 <- as.numeric(data.all$TC_2020)
data.all$PY <- as.numeric(data.all$PY)

# Remove excluded rows from data.all

data.all <- data.all[is.na(data.all$excluded),]

# Trim data.irr down to relevant variables

data.irr <- select(data.irr, 
                   UT, DI, AU, TI, PY, 
                   coder, sample_size_orig, sample_size_BA, sample_size_PhD, sample_size_final,
                   matches_orig_BA, matches_orig_PhD, matches_BA_PhD, matches_all, irr_resolver, irr_resolver_comment)
