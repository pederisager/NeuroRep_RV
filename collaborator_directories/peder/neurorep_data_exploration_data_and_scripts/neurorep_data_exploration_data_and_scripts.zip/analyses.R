###############################
# Exploratory analysis script #
###############################


#### Load packages #### 

library(tidyverse)
library(psych)



#### Load and clean data #### 

source("load_and_clean_data.R")



#### Analyses #### 

# Using the codebook 

## To check the description of a variable, use $ to find the variable in codebook.data.all. E.g.:

codebook.data.all$UT
codebook.data.all$coder
codebook.data.all$tcs

## To view the entire codebook: 

view(t(codebook.data.all))

## The codebook contains a description of all variables contained in data.all and data.bib. 



# Dataset summaries

## data.bib
 
pubyear.freq <- table(data.bib$PY)
barplot(pubyear.freq, xlab = "Publication year")  # Plot frequency of publication years

hist(data.bib$TC_2020, breaks = 50, xlab = "Citation count (WoS)", main = "")  # Plot citation count distribution

cor(select(data.bib, 
           TC, 
           TC_2020, 
           crossref_citations, 
           scopus_citations, 
           tcs, 
           altmetric_score), 
    use = "complete.obs")  # Print correlation matrix for various citation count sources - all are highly intercorrelated, except altmetric count, which is weakly correlated with all other sources (as is known from literature). 

## data.all

data.all$years.since.pub <- 2020 - data.all$PY
data.all$RV <- (data.all$TC_2020 / (data.all$years.since.pub + 1)) * (1 / data.all$sample_size)  # Calculate RV for all records in data.all

describe(select(data.all, 
                TC_2020,
                years.since.pub, 
                sample_size,
                RV))  # Descriptive statistics for RV and all variables used to calculate it

par(mfrow=c(2,2))

hist(data.all$sample_size, breaks = 300, xlim = c(0, 200), xlab = "Sample size", main = "")  #Plot sample size (cut values over 200)
hist(data.all$TC_2020, breaks = 50, xlab = "Citation counts", main = "")  #Plot citation count
barplot(table(data.all$PY), xlab = "Publication year", ylab = "Frequency")  # Plot log sample size
hist(data.all$RV, breaks = 50, xlab = "Replicaton value", main = "")  #Plot replication value

par(mfrow=c(1,1))  # Reset par(mfrow)

### Test if sample size is uncorrelated with yearly citation count, as is predicted by the psychometric model in thesis chapter 2

cor.test(data.all$sample_size, data.all$TC_2020/data.all$years.since.pub, na.action = "na.rm")  # correlation test - likely incorrectly specified given the massive skew of both variables

par(mfrow=c(2,1))

plot(data.all$sample_size, data.all$TC_2020/data.all$years.since.pub, xlab="sample size", ylab="citation count per year")  # plot sample size by citation count, raw
plot(log(data.all$sample_size), log(data.all$TC_2020/data.all$years.since.pub), xlab="log sample size", ylab="log citation count per year")  # plot sample size by citation count, log

par(mfrow=c(1,1))  # Reset par(mfrow)

## data.irr

ICC(data.irr[, c("sample_size_orig", "sample_size_BA", "sample_size_PhD")])  # Intraclass correlation between the three sample size coders

cor(select(.data = data.irr, 
           sample_size_orig, 
           sample_size_BA, 
           sample_size_PhD, 
           sample_size_final))  # Correlation matrix between the three different coders and the final sample size after resolving disagreements
